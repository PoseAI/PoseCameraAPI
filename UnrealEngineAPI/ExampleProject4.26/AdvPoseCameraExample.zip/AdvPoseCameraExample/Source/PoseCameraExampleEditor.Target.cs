// Pose AI 2021.

using UnrealBuildTool;
using System.Collections.Generic;

public class PoseCameraExampleEditorTarget : TargetRules
{
	public PoseCameraExampleEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.V2;

		ExtraModuleNames.AddRange( new string[] { "PoseCameraExample" } );
	}
}
