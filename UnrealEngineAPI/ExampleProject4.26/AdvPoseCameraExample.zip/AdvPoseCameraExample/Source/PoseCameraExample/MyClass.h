// Pose AI 2021.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class POSECAMERAEXAMPLE_API MyClass
{
public:
	MyClass();
	~MyClass();
};
