// Pose AI 2021.

#include "PoseCameraExample.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, PoseCameraExample, "PoseCameraExample" );
