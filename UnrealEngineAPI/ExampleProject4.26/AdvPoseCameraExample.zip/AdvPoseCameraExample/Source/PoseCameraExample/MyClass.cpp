// Pose AI 2021.


#include "MyClass.h"

MyClass::MyClass()
{
}

MyClass::~MyClass()
{
}
